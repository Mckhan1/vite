<script setup>
import Connection from '../components/Connection.vue';
</script>

<template>
  <div>
    <Connection />
  </div>
</template>