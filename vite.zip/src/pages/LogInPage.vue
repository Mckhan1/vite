<script setup>
import LogIn from '../components/LogIn.vue';
</script>

<template>
  <div>
    <LogIn />
  </div>
</template>