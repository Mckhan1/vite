<script setup>
import OneScreen from '../components/OneScreen.vue'
</script>

<template>
  <div>
    <OneScreen />
  </div>
</template>