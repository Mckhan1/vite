<script setup>
import Check from '../components/Check.vue';
</script>

<template>
  <div>
    <Check />
  </div>
</template>